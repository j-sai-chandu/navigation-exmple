<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Collection\\Providers\\CollectionServiceProvider',
    1 => 'Modules\\Collection\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Collection\\Providers\\CollectionServiceProvider',
    1 => 'Modules\\Collection\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);