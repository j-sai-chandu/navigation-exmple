<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Taxon\\Providers\\TaxonServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Taxon\\Providers\\TaxonServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);