<?php

return [
    'name' => 'Collection',
];
