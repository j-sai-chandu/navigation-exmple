<?php

return [

    'name' => 'Name',
    'slug' => 'Slug',
    'site' => 'Site',
    'taxon_id' => 'Taxon',
    'status' => 'Status',
    'description' => 'Description',
    'meta_title' => 'Meta Title',
    'meta_keywords' => 'Meta Keywords',
    'meta_description' => 'Meta Description',
    'order' => 'Order',

];
