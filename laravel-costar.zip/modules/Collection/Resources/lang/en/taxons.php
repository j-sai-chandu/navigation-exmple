<?php

return [

    'name' => 'Name',
    'slug' => 'Slug',
    'description' => 'Description',
    'taxon_id' => 'Taxon',
    'status' => 'Status',
    'meta_title' => 'Meta Title',
    'meta_keywords' => 'Meta Keywords',
    'meta_description' => 'Meta Description',

];
