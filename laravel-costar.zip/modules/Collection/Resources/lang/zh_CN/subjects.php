<?php

return [

    'name' => '名称',
    'slug' => '别名',
    'site' => 'Site',
    'taxon_id' => '分类',
    'status' => '状态',
    'description' => '描述',
    'meta_title' => 'Meta Title',
    'meta_keywords' => 'Meta Keywords',
    'meta_description' => 'Meta Description',
    'order' => '排序',

];
