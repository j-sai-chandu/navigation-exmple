<?php

return [
    'name' => 'Taxon',
];
