<?php

namespace Costar\DataTables\Exceptions;

class Exception extends \Exception
{
}
