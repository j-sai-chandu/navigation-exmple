<?php

namespace App\Handlers;

class LfmConfigHandler extends \Costar\LaravelFilemanager\Handlers\ConfigHandler
{
    public function userField()
    {
        return parent::userField();
    }
}
